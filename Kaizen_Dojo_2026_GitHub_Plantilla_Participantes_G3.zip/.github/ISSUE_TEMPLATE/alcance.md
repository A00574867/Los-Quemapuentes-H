---
name: Alcance individual
about: Definir una contribución técnica negociada de Kaizen Dōjō
labels: alcance
---

**Código de alcance:** [MS01 / SL04 / TL06 / AR03]
**Responsable:** [@alias]
**Frontera personal:** [F1–F4]
**Carta:** [D1/D2/S1/S2/E1/E2]
**Criterio de aceptación:** [qué podremos demostrar]
**Dependencias:** [hardware/código/personas]
**Entregable:** [archivo o evidencia]

- [ ] Kata diagnóstico / familiarización
- [ ] Kata de construcción / integración
- [ ] Kata de verificación
- [ ] Evidencia individual enlazada
