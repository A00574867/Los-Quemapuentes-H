---
name: Bloqueo o falla
about: Registrar una dificultad reproducible y su próxima prueba
labels: bloqueo
---

**Problema observado:**
**Configuración (versión, material, entorno):**
**Cómo reproducirlo:**
**Resultado esperado/obtenido:**
**Hipótesis y siguiente prueba:**
**Responsable:**
