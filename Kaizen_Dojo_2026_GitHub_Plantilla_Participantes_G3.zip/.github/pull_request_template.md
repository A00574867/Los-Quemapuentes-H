## ¿Qué cambia?
[Explicar brevemente qué se agregó o modificó.]

**Alcance del catálogo:** [MS01/SL04/TL06/AR03]  
**Responsable:** [@alias]  
**Evidencia E1–E5:** [E2, E3, etc.]

## ¿Cómo lo comprobé?
- [ ] Ejecuté la función o procedimiento bajo condiciones seguras.
- [ ] Registré pruebas (o expliqué por qué todavía no pueden ejecutarse).
- [ ] Añadí vínculo a mi portafolio y al alcance correspondiente.
- [ ] Revisé que no hay secretos ni datos personales.

**Enlace de pruebas:** [ruta relativa o URL controlada]  
**Limitación/conclusión:** [dato y explicación]
